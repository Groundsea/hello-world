/*
 * VLIB API definitions 2021-10-16 12:42:40
 * Input file: flow_types.api
 * Automatically generated: please edit the input file NOT this file!
 */

#include <stdbool.h>
#if defined(vl_msg_id)||defined(vl_union_id) \
    || defined(vl_printfun) ||defined(vl_endianfun) \
    || defined(vl_api_version)||defined(vl_typedefs) \
    || defined(vl_msg_name)||defined(vl_msg_name_crc_list) \
    || defined(vl_api_version_tuple)
/* ok, something was selected */
#else
#warning no content included from flow_types.api
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))
/* Imported API files */
#ifndef vl_api_version
#include <vnet/ethernet/ethernet_types.api.h>
#include <vnet/ip/ip_types.api.h>
#endif

/****** Message ID / handler enum ******/

#ifdef vl_msg_id
#endif
/****** Message names ******/

#ifdef vl_msg_name
#endif
/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_flow_types 
#endif
/****** Typedefs ******/

#ifdef vl_typedefs
#include "flow_types.api_types.h"
#endif
/****** Print functions *****/
#ifdef vl_printfun
#ifndef included_flow_types_printfun_types
#define included_flow_types_printfun_types

static inline u8 *format_vl_api_flow_type_t (u8 *s, va_list * args)
{
    vl_api_flow_type_t *a = va_arg (*args, vl_api_flow_type_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    switch(*a) {
    case 1:
        return format(s, "FLOW_TYPE_ETHERNET");
    case 2:
        return format(s, "FLOW_TYPE_IP4");
    case 3:
        return format(s, "FLOW_TYPE_IP6");
    case 4:
        return format(s, "FLOW_TYPE_IP4_L2TPV3OIP");
    case 5:
        return format(s, "FLOW_TYPE_IP4_IPSEC_ESP");
    case 6:
        return format(s, "FLOW_TYPE_IP4_IPSEC_AH");
    case 7:
        return format(s, "FLOW_TYPE_IP4_N_TUPLE");
    case 8:
        return format(s, "FLOW_TYPE_IP6_N_TUPLE");
    case 9:
        return format(s, "FLOW_TYPE_IP4_N_TUPLE_TAGGED");
    case 10:
        return format(s, "FLOW_TYPE_IP6_N_TUPLE_TAGGED");
    case 11:
        return format(s, "FLOW_TYPE_IP4_VXLAN");
    case 12:
        return format(s, "FLOW_TYPE_IP6_VXLAN");
    case 13:
        return format(s, "FLOW_TYPE_IP4_GTPC");
    case 14:
        return format(s, "FLOW_TYPE_IP4_GTPU");
    }
    return s;
}

static inline u8 *format_vl_api_flow_action_t (u8 *s, va_list * args)
{
    vl_api_flow_action_t *a = va_arg (*args, vl_api_flow_action_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    switch(*a) {
    case 1:
        return format(s, "FLOW_ACTION_COUNT");
    case 2:
        return format(s, "FLOW_ACTION_MARK");
    case 4:
        return format(s, "FLOW_ACTION_BUFFER_ADVANCE");
    case 8:
        return format(s, "FLOW_ACTION_REDIRECT_TO_NODE");
    case 16:
        return format(s, "FLOW_ACTION_REDIRECT_TO_QUEUE");
    case 64:
        return format(s, "FLOW_ACTION_DROP");
    }
    return s;
}

static inline u8 *format_vl_api_ip_port_and_mask_t (u8 *s, va_list * args)
{
    vl_api_ip_port_and_mask_t *a = va_arg (*args, vl_api_ip_port_and_mask_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Uport: %u", format_white_space, indent, a->port);
    s = format(s, "\n%Umask: %u", format_white_space, indent, a->mask);
    return s;
}

static inline u8 *format_vl_api_ip_prot_and_mask_t (u8 *s, va_list * args)
{
    vl_api_ip_prot_and_mask_t *a = va_arg (*args, vl_api_ip_prot_and_mask_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Uprot: %U", format_white_space, indent, format_vl_api_ip_proto_t, &a->prot, indent);
    s = format(s, "\n%Umask: %u", format_white_space, indent, a->mask);
    return s;
}

static inline u8 *format_vl_api_flow_ethernet_t (u8 *s, va_list * args)
{
    vl_api_flow_ethernet_t *a = va_arg (*args, vl_api_flow_ethernet_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Ufoo: %ld", format_white_space, indent, a->foo);
    s = format(s, "\n%Usrc_addr: %U", format_white_space, indent, format_vl_api_mac_address_t, &a->src_addr, indent);
    s = format(s, "\n%Udst_addr: %U", format_white_space, indent, format_vl_api_mac_address_t, &a->dst_addr, indent);
    s = format(s, "\n%Utype: %u", format_white_space, indent, a->type);
    return s;
}

static inline u8 *format_vl_api_flow_ip4_t (u8 *s, va_list * args)
{
    vl_api_flow_ip4_t *a = va_arg (*args, vl_api_flow_ip4_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Ufoo: %ld", format_white_space, indent, a->foo);
    s = format(s, "\n%Usrc_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->src_addr, indent);
    s = format(s, "\n%Udst_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->dst_addr, indent);
    s = format(s, "\n%Uprotocol: %U", format_white_space, indent, format_vl_api_ip_prot_and_mask_t, &a->protocol, indent);
    return s;
}

static inline u8 *format_vl_api_flow_ip6_t (u8 *s, va_list * args)
{
    vl_api_flow_ip6_t *a = va_arg (*args, vl_api_flow_ip6_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Ufoo: %ld", format_white_space, indent, a->foo);
    s = format(s, "\n%Usrc_addr: %U", format_white_space, indent, format_vl_api_ip6_address_and_mask_t, &a->src_addr, indent);
    s = format(s, "\n%Udst_addr: %U", format_white_space, indent, format_vl_api_ip6_address_and_mask_t, &a->dst_addr, indent);
    s = format(s, "\n%Uprotocol: %U", format_white_space, indent, format_vl_api_ip_prot_and_mask_t, &a->protocol, indent);
    return s;
}

static inline u8 *format_vl_api_flow_ip4_n_tuple_t (u8 *s, va_list * args)
{
    vl_api_flow_ip4_n_tuple_t *a = va_arg (*args, vl_api_flow_ip4_n_tuple_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Ufoo: %ld", format_white_space, indent, a->foo);
    s = format(s, "\n%Usrc_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->src_addr, indent);
    s = format(s, "\n%Udst_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->dst_addr, indent);
    s = format(s, "\n%Uprotocol: %U", format_white_space, indent, format_vl_api_ip_prot_and_mask_t, &a->protocol, indent);
    s = format(s, "\n%Usrc_port: %U", format_white_space, indent, format_vl_api_ip_port_and_mask_t, &a->src_port, indent);
    s = format(s, "\n%Udst_port: %U", format_white_space, indent, format_vl_api_ip_port_and_mask_t, &a->dst_port, indent);
    return s;
}

static inline u8 *format_vl_api_flow_ip6_n_tuple_t (u8 *s, va_list * args)
{
    vl_api_flow_ip6_n_tuple_t *a = va_arg (*args, vl_api_flow_ip6_n_tuple_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Ufoo: %ld", format_white_space, indent, a->foo);
    s = format(s, "\n%Usrc_addr: %U", format_white_space, indent, format_vl_api_ip6_address_and_mask_t, &a->src_addr, indent);
    s = format(s, "\n%Udst_addr: %U", format_white_space, indent, format_vl_api_ip6_address_and_mask_t, &a->dst_addr, indent);
    s = format(s, "\n%Uprotocol: %U", format_white_space, indent, format_vl_api_ip_prot_and_mask_t, &a->protocol, indent);
    s = format(s, "\n%Usrc_port: %U", format_white_space, indent, format_vl_api_ip_port_and_mask_t, &a->src_port, indent);
    s = format(s, "\n%Udst_port: %U", format_white_space, indent, format_vl_api_ip_port_and_mask_t, &a->dst_port, indent);
    return s;
}

static inline u8 *format_vl_api_flow_ip4_n_tuple_tagged_t (u8 *s, va_list * args)
{
    vl_api_flow_ip4_n_tuple_tagged_t *a = va_arg (*args, vl_api_flow_ip4_n_tuple_tagged_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Ufoo: %ld", format_white_space, indent, a->foo);
    s = format(s, "\n%Usrc_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->src_addr, indent);
    s = format(s, "\n%Udst_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->dst_addr, indent);
    s = format(s, "\n%Uprotocol: %U", format_white_space, indent, format_vl_api_ip_prot_and_mask_t, &a->protocol, indent);
    s = format(s, "\n%Usrc_port: %U", format_white_space, indent, format_vl_api_ip_port_and_mask_t, &a->src_port, indent);
    s = format(s, "\n%Udst_port: %U", format_white_space, indent, format_vl_api_ip_port_and_mask_t, &a->dst_port, indent);
    return s;
}

static inline u8 *format_vl_api_flow_ip6_n_tuple_tagged_t (u8 *s, va_list * args)
{
    vl_api_flow_ip6_n_tuple_tagged_t *a = va_arg (*args, vl_api_flow_ip6_n_tuple_tagged_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Ufoo: %ld", format_white_space, indent, a->foo);
    s = format(s, "\n%Usrc_addr: %U", format_white_space, indent, format_vl_api_ip6_address_and_mask_t, &a->src_addr, indent);
    s = format(s, "\n%Udst_addr: %U", format_white_space, indent, format_vl_api_ip6_address_and_mask_t, &a->dst_addr, indent);
    s = format(s, "\n%Uprotocol: %U", format_white_space, indent, format_vl_api_ip_prot_and_mask_t, &a->protocol, indent);
    s = format(s, "\n%Usrc_port: %U", format_white_space, indent, format_vl_api_ip_port_and_mask_t, &a->src_port, indent);
    s = format(s, "\n%Udst_port: %U", format_white_space, indent, format_vl_api_ip_port_and_mask_t, &a->dst_port, indent);
    return s;
}

static inline u8 *format_vl_api_flow_ip4_l2tpv3oip_t (u8 *s, va_list * args)
{
    vl_api_flow_ip4_l2tpv3oip_t *a = va_arg (*args, vl_api_flow_ip4_l2tpv3oip_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Ufoo: %ld", format_white_space, indent, a->foo);
    s = format(s, "\n%Usrc_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->src_addr, indent);
    s = format(s, "\n%Udst_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->dst_addr, indent);
    s = format(s, "\n%Uprotocol: %U", format_white_space, indent, format_vl_api_ip_prot_and_mask_t, &a->protocol, indent);
    s = format(s, "\n%Usession_id: %u", format_white_space, indent, a->session_id);
    return s;
}

static inline u8 *format_vl_api_flow_ip4_ipsec_esp_t (u8 *s, va_list * args)
{
    vl_api_flow_ip4_ipsec_esp_t *a = va_arg (*args, vl_api_flow_ip4_ipsec_esp_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Ufoo: %ld", format_white_space, indent, a->foo);
    s = format(s, "\n%Usrc_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->src_addr, indent);
    s = format(s, "\n%Udst_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->dst_addr, indent);
    s = format(s, "\n%Uprotocol: %U", format_white_space, indent, format_vl_api_ip_prot_and_mask_t, &a->protocol, indent);
    s = format(s, "\n%Uspi: %u", format_white_space, indent, a->spi);
    return s;
}

static inline u8 *format_vl_api_flow_ip4_ipsec_ah_t (u8 *s, va_list * args)
{
    vl_api_flow_ip4_ipsec_ah_t *a = va_arg (*args, vl_api_flow_ip4_ipsec_ah_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Ufoo: %ld", format_white_space, indent, a->foo);
    s = format(s, "\n%Usrc_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->src_addr, indent);
    s = format(s, "\n%Udst_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->dst_addr, indent);
    s = format(s, "\n%Uprotocol: %U", format_white_space, indent, format_vl_api_ip_prot_and_mask_t, &a->protocol, indent);
    s = format(s, "\n%Uspi: %u", format_white_space, indent, a->spi);
    return s;
}

static inline u8 *format_vl_api_flow_ip4_vxlan_t (u8 *s, va_list * args)
{
    vl_api_flow_ip4_vxlan_t *a = va_arg (*args, vl_api_flow_ip4_vxlan_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Ufoo: %ld", format_white_space, indent, a->foo);
    s = format(s, "\n%Usrc_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->src_addr, indent);
    s = format(s, "\n%Udst_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->dst_addr, indent);
    s = format(s, "\n%Uprotocol: %U", format_white_space, indent, format_vl_api_ip_prot_and_mask_t, &a->protocol, indent);
    s = format(s, "\n%Usrc_port: %U", format_white_space, indent, format_vl_api_ip_port_and_mask_t, &a->src_port, indent);
    s = format(s, "\n%Udst_port: %U", format_white_space, indent, format_vl_api_ip_port_and_mask_t, &a->dst_port, indent);
    s = format(s, "\n%Uvni: %u", format_white_space, indent, a->vni);
    return s;
}

static inline u8 *format_vl_api_flow_ip6_vxlan_t (u8 *s, va_list * args)
{
    vl_api_flow_ip6_vxlan_t *a = va_arg (*args, vl_api_flow_ip6_vxlan_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Ufoo: %ld", format_white_space, indent, a->foo);
    s = format(s, "\n%Usrc_addr: %U", format_white_space, indent, format_vl_api_ip6_address_and_mask_t, &a->src_addr, indent);
    s = format(s, "\n%Udst_addr: %U", format_white_space, indent, format_vl_api_ip6_address_and_mask_t, &a->dst_addr, indent);
    s = format(s, "\n%Uprotocol: %U", format_white_space, indent, format_vl_api_ip_prot_and_mask_t, &a->protocol, indent);
    s = format(s, "\n%Usrc_port: %U", format_white_space, indent, format_vl_api_ip_port_and_mask_t, &a->src_port, indent);
    s = format(s, "\n%Udst_port: %U", format_white_space, indent, format_vl_api_ip_port_and_mask_t, &a->dst_port, indent);
    s = format(s, "\n%Uvni: %u", format_white_space, indent, a->vni);
    return s;
}

static inline u8 *format_vl_api_flow_ip4_gtpc_t (u8 *s, va_list * args)
{
    vl_api_flow_ip4_gtpc_t *a = va_arg (*args, vl_api_flow_ip4_gtpc_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Ufoo: %ld", format_white_space, indent, a->foo);
    s = format(s, "\n%Usrc_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->src_addr, indent);
    s = format(s, "\n%Udst_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->dst_addr, indent);
    s = format(s, "\n%Uprotocol: %U", format_white_space, indent, format_vl_api_ip_prot_and_mask_t, &a->protocol, indent);
    s = format(s, "\n%Usrc_port: %U", format_white_space, indent, format_vl_api_ip_port_and_mask_t, &a->src_port, indent);
    s = format(s, "\n%Udst_port: %U", format_white_space, indent, format_vl_api_ip_port_and_mask_t, &a->dst_port, indent);
    s = format(s, "\n%Uteid: %u", format_white_space, indent, a->teid);
    return s;
}

static inline u8 *format_vl_api_flow_ip4_gtpu_t (u8 *s, va_list * args)
{
    vl_api_flow_ip4_gtpu_t *a = va_arg (*args, vl_api_flow_ip4_gtpu_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Ufoo: %ld", format_white_space, indent, a->foo);
    s = format(s, "\n%Usrc_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->src_addr, indent);
    s = format(s, "\n%Udst_addr: %U", format_white_space, indent, format_vl_api_ip4_address_and_mask_t, &a->dst_addr, indent);
    s = format(s, "\n%Uprotocol: %U", format_white_space, indent, format_vl_api_ip_prot_and_mask_t, &a->protocol, indent);
    s = format(s, "\n%Usrc_port: %U", format_white_space, indent, format_vl_api_ip_port_and_mask_t, &a->src_port, indent);
    s = format(s, "\n%Udst_port: %U", format_white_space, indent, format_vl_api_ip_port_and_mask_t, &a->dst_port, indent);
    s = format(s, "\n%Uteid: %u", format_white_space, indent, a->teid);
    return s;
}

static inline u8 *format_vl_api_flow_t (u8 *s, va_list * args)
{
    vl_api_flow_t *a = va_arg (*args, vl_api_flow_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Uethernet: %U", format_white_space, indent, format_vl_api_flow_ethernet_t, &a->ethernet, indent);
    s = format(s, "\n%Uip4: %U", format_white_space, indent, format_vl_api_flow_ip4_t, &a->ip4, indent);
    s = format(s, "\n%Uip6: %U", format_white_space, indent, format_vl_api_flow_ip6_t, &a->ip6, indent);
    s = format(s, "\n%Uip4_l2tpv3oip: %U", format_white_space, indent, format_vl_api_flow_ip4_l2tpv3oip_t, &a->ip4_l2tpv3oip, indent);
    s = format(s, "\n%Uip4_ipsec_esp: %U", format_white_space, indent, format_vl_api_flow_ip4_ipsec_esp_t, &a->ip4_ipsec_esp, indent);
    s = format(s, "\n%Uip4_ipsec_ah: %U", format_white_space, indent, format_vl_api_flow_ip4_ipsec_ah_t, &a->ip4_ipsec_ah, indent);
    s = format(s, "\n%Uip4_n_tuple: %U", format_white_space, indent, format_vl_api_flow_ip4_n_tuple_t, &a->ip4_n_tuple, indent);
    s = format(s, "\n%Uip6_n_tuple: %U", format_white_space, indent, format_vl_api_flow_ip6_n_tuple_t, &a->ip6_n_tuple, indent);
    s = format(s, "\n%Uip4_n_tuple_tagged: %U", format_white_space, indent, format_vl_api_flow_ip4_n_tuple_tagged_t, &a->ip4_n_tuple_tagged, indent);
    s = format(s, "\n%Uip6_n_tuple_tagged: %U", format_white_space, indent, format_vl_api_flow_ip6_n_tuple_tagged_t, &a->ip6_n_tuple_tagged, indent);
    s = format(s, "\n%Uip4_vxlan: %U", format_white_space, indent, format_vl_api_flow_ip4_vxlan_t, &a->ip4_vxlan, indent);
    s = format(s, "\n%Uip6_vxlan: %U", format_white_space, indent, format_vl_api_flow_ip6_vxlan_t, &a->ip6_vxlan, indent);
    s = format(s, "\n%Uip4_gtpc: %U", format_white_space, indent, format_vl_api_flow_ip4_gtpc_t, &a->ip4_gtpc, indent);
    s = format(s, "\n%Uip4_gtpu: %U", format_white_space, indent, format_vl_api_flow_ip4_gtpu_t, &a->ip4_gtpu, indent);
    return s;
}

static inline u8 *format_vl_api_flow_rule_t (u8 *s, va_list * args)
{
    vl_api_flow_rule_t *a = va_arg (*args, vl_api_flow_rule_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Utype: %U", format_white_space, indent, format_vl_api_flow_type_t, &a->type, indent);
    s = format(s, "\n%Uindex: %u", format_white_space, indent, a->index);
    s = format(s, "\n%Uactions: %U", format_white_space, indent, format_vl_api_flow_action_t, &a->actions, indent);
    s = format(s, "\n%Umark_flow_id: %u", format_white_space, indent, a->mark_flow_id);
    s = format(s, "\n%Uredirect_node_index: %u", format_white_space, indent, a->redirect_node_index);
    s = format(s, "\n%Uredirect_device_input_next_index: %u", format_white_space, indent, a->redirect_device_input_next_index);
    s = format(s, "\n%Uredirect_queue: %u", format_white_space, indent, a->redirect_queue);
    s = format(s, "\n%Ubuffer_advance: %ld", format_white_space, indent, a->buffer_advance);
    s = format(s, "\n%Uflow: %U", format_white_space, indent, format_vl_api_flow_t, &a->flow, indent);
    return s;
}


#endif
#endif /* vl_printfun_types */
/****** Print functions *****/
#ifdef vl_printfun
#ifndef included_flow_types_printfun
#define included_flow_types_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif


#endif
#endif /* vl_printfun */

/****** Endian swap functions *****/
#ifdef vl_endianfun
#ifndef included_flow_types_endianfun
#define included_flow_types_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_flow_type_t_endian (vl_api_flow_type_t *a)
{
    int i __attribute__((unused));
    *a = clib_net_to_host_u32(*a);
}

static inline void vl_api_flow_action_t_endian (vl_api_flow_action_t *a)
{
    int i __attribute__((unused));
    *a = clib_net_to_host_u32(*a);
}

static inline void vl_api_ip_port_and_mask_t_endian (vl_api_ip_port_and_mask_t *a)
{
    int i __attribute__((unused));
    a->port = clib_net_to_host_u16(a->port);
    a->mask = clib_net_to_host_u16(a->mask);
}

static inline void vl_api_ip_prot_and_mask_t_endian (vl_api_ip_prot_and_mask_t *a)
{
    int i __attribute__((unused));
    vl_api_ip_proto_t_endian(&a->prot);
    /* a->mask = a->mask (no-op) */
}

static inline void vl_api_flow_ethernet_t_endian (vl_api_flow_ethernet_t *a)
{
    int i __attribute__((unused));
    a->foo = clib_net_to_host_i32(a->foo);
    vl_api_mac_address_t_endian(&a->src_addr);
    vl_api_mac_address_t_endian(&a->dst_addr);
    a->type = clib_net_to_host_u16(a->type);
}

static inline void vl_api_flow_ip4_t_endian (vl_api_flow_ip4_t *a)
{
    int i __attribute__((unused));
    a->foo = clib_net_to_host_i32(a->foo);
    vl_api_ip4_address_and_mask_t_endian(&a->src_addr);
    vl_api_ip4_address_and_mask_t_endian(&a->dst_addr);
    vl_api_ip_prot_and_mask_t_endian(&a->protocol);
}

static inline void vl_api_flow_ip6_t_endian (vl_api_flow_ip6_t *a)
{
    int i __attribute__((unused));
    a->foo = clib_net_to_host_i32(a->foo);
    vl_api_ip6_address_and_mask_t_endian(&a->src_addr);
    vl_api_ip6_address_and_mask_t_endian(&a->dst_addr);
    vl_api_ip_prot_and_mask_t_endian(&a->protocol);
}

static inline void vl_api_flow_ip4_n_tuple_t_endian (vl_api_flow_ip4_n_tuple_t *a)
{
    int i __attribute__((unused));
    a->foo = clib_net_to_host_i32(a->foo);
    vl_api_ip4_address_and_mask_t_endian(&a->src_addr);
    vl_api_ip4_address_and_mask_t_endian(&a->dst_addr);
    vl_api_ip_prot_and_mask_t_endian(&a->protocol);
    vl_api_ip_port_and_mask_t_endian(&a->src_port);
    vl_api_ip_port_and_mask_t_endian(&a->dst_port);
}

static inline void vl_api_flow_ip6_n_tuple_t_endian (vl_api_flow_ip6_n_tuple_t *a)
{
    int i __attribute__((unused));
    a->foo = clib_net_to_host_i32(a->foo);
    vl_api_ip6_address_and_mask_t_endian(&a->src_addr);
    vl_api_ip6_address_and_mask_t_endian(&a->dst_addr);
    vl_api_ip_prot_and_mask_t_endian(&a->protocol);
    vl_api_ip_port_and_mask_t_endian(&a->src_port);
    vl_api_ip_port_and_mask_t_endian(&a->dst_port);
}

static inline void vl_api_flow_ip4_n_tuple_tagged_t_endian (vl_api_flow_ip4_n_tuple_tagged_t *a)
{
    int i __attribute__((unused));
    a->foo = clib_net_to_host_i32(a->foo);
    vl_api_ip4_address_and_mask_t_endian(&a->src_addr);
    vl_api_ip4_address_and_mask_t_endian(&a->dst_addr);
    vl_api_ip_prot_and_mask_t_endian(&a->protocol);
    vl_api_ip_port_and_mask_t_endian(&a->src_port);
    vl_api_ip_port_and_mask_t_endian(&a->dst_port);
}

static inline void vl_api_flow_ip6_n_tuple_tagged_t_endian (vl_api_flow_ip6_n_tuple_tagged_t *a)
{
    int i __attribute__((unused));
    a->foo = clib_net_to_host_i32(a->foo);
    vl_api_ip6_address_and_mask_t_endian(&a->src_addr);
    vl_api_ip6_address_and_mask_t_endian(&a->dst_addr);
    vl_api_ip_prot_and_mask_t_endian(&a->protocol);
    vl_api_ip_port_and_mask_t_endian(&a->src_port);
    vl_api_ip_port_and_mask_t_endian(&a->dst_port);
}

static inline void vl_api_flow_ip4_l2tpv3oip_t_endian (vl_api_flow_ip4_l2tpv3oip_t *a)
{
    int i __attribute__((unused));
    a->foo = clib_net_to_host_i32(a->foo);
    vl_api_ip4_address_and_mask_t_endian(&a->src_addr);
    vl_api_ip4_address_and_mask_t_endian(&a->dst_addr);
    vl_api_ip_prot_and_mask_t_endian(&a->protocol);
    a->session_id = clib_net_to_host_u32(a->session_id);
}

static inline void vl_api_flow_ip4_ipsec_esp_t_endian (vl_api_flow_ip4_ipsec_esp_t *a)
{
    int i __attribute__((unused));
    a->foo = clib_net_to_host_i32(a->foo);
    vl_api_ip4_address_and_mask_t_endian(&a->src_addr);
    vl_api_ip4_address_and_mask_t_endian(&a->dst_addr);
    vl_api_ip_prot_and_mask_t_endian(&a->protocol);
    a->spi = clib_net_to_host_u32(a->spi);
}

static inline void vl_api_flow_ip4_ipsec_ah_t_endian (vl_api_flow_ip4_ipsec_ah_t *a)
{
    int i __attribute__((unused));
    a->foo = clib_net_to_host_i32(a->foo);
    vl_api_ip4_address_and_mask_t_endian(&a->src_addr);
    vl_api_ip4_address_and_mask_t_endian(&a->dst_addr);
    vl_api_ip_prot_and_mask_t_endian(&a->protocol);
    a->spi = clib_net_to_host_u32(a->spi);
}

static inline void vl_api_flow_ip4_vxlan_t_endian (vl_api_flow_ip4_vxlan_t *a)
{
    int i __attribute__((unused));
    a->foo = clib_net_to_host_i32(a->foo);
    vl_api_ip4_address_and_mask_t_endian(&a->src_addr);
    vl_api_ip4_address_and_mask_t_endian(&a->dst_addr);
    vl_api_ip_prot_and_mask_t_endian(&a->protocol);
    vl_api_ip_port_and_mask_t_endian(&a->src_port);
    vl_api_ip_port_and_mask_t_endian(&a->dst_port);
    a->vni = clib_net_to_host_u32(a->vni);
}

static inline void vl_api_flow_ip6_vxlan_t_endian (vl_api_flow_ip6_vxlan_t *a)
{
    int i __attribute__((unused));
    a->foo = clib_net_to_host_i32(a->foo);
    vl_api_ip6_address_and_mask_t_endian(&a->src_addr);
    vl_api_ip6_address_and_mask_t_endian(&a->dst_addr);
    vl_api_ip_prot_and_mask_t_endian(&a->protocol);
    vl_api_ip_port_and_mask_t_endian(&a->src_port);
    vl_api_ip_port_and_mask_t_endian(&a->dst_port);
    a->vni = clib_net_to_host_u32(a->vni);
}

static inline void vl_api_flow_ip4_gtpc_t_endian (vl_api_flow_ip4_gtpc_t *a)
{
    int i __attribute__((unused));
    a->foo = clib_net_to_host_i32(a->foo);
    vl_api_ip4_address_and_mask_t_endian(&a->src_addr);
    vl_api_ip4_address_and_mask_t_endian(&a->dst_addr);
    vl_api_ip_prot_and_mask_t_endian(&a->protocol);
    vl_api_ip_port_and_mask_t_endian(&a->src_port);
    vl_api_ip_port_and_mask_t_endian(&a->dst_port);
    a->teid = clib_net_to_host_u32(a->teid);
}

static inline void vl_api_flow_ip4_gtpu_t_endian (vl_api_flow_ip4_gtpu_t *a)
{
    int i __attribute__((unused));
    a->foo = clib_net_to_host_i32(a->foo);
    vl_api_ip4_address_and_mask_t_endian(&a->src_addr);
    vl_api_ip4_address_and_mask_t_endian(&a->dst_addr);
    vl_api_ip_prot_and_mask_t_endian(&a->protocol);
    vl_api_ip_port_and_mask_t_endian(&a->src_port);
    vl_api_ip_port_and_mask_t_endian(&a->dst_port);
    a->teid = clib_net_to_host_u32(a->teid);
}

static inline void vl_api_flow_t_endian (vl_api_flow_t *a)
{
    int i __attribute__((unused));
    vl_api_flow_ethernet_t_endian(&a->ethernet);
    vl_api_flow_ip4_t_endian(&a->ip4);
    vl_api_flow_ip6_t_endian(&a->ip6);
    vl_api_flow_ip4_l2tpv3oip_t_endian(&a->ip4_l2tpv3oip);
    vl_api_flow_ip4_ipsec_esp_t_endian(&a->ip4_ipsec_esp);
    vl_api_flow_ip4_ipsec_ah_t_endian(&a->ip4_ipsec_ah);
    vl_api_flow_ip4_n_tuple_t_endian(&a->ip4_n_tuple);
    vl_api_flow_ip6_n_tuple_t_endian(&a->ip6_n_tuple);
    vl_api_flow_ip4_n_tuple_tagged_t_endian(&a->ip4_n_tuple_tagged);
    vl_api_flow_ip6_n_tuple_tagged_t_endian(&a->ip6_n_tuple_tagged);
    vl_api_flow_ip4_vxlan_t_endian(&a->ip4_vxlan);
    vl_api_flow_ip6_vxlan_t_endian(&a->ip6_vxlan);
    vl_api_flow_ip4_gtpc_t_endian(&a->ip4_gtpc);
    vl_api_flow_ip4_gtpu_t_endian(&a->ip4_gtpu);
}

static inline void vl_api_flow_rule_t_endian (vl_api_flow_rule_t *a)
{
    int i __attribute__((unused));
    vl_api_flow_type_t_endian(&a->type);
    a->index = clib_net_to_host_u32(a->index);
    vl_api_flow_action_t_endian(&a->actions);
    a->mark_flow_id = clib_net_to_host_u32(a->mark_flow_id);
    a->redirect_node_index = clib_net_to_host_u32(a->redirect_node_index);
    a->redirect_device_input_next_index = clib_net_to_host_u32(a->redirect_device_input_next_index);
    a->redirect_queue = clib_net_to_host_u32(a->redirect_queue);
    a->buffer_advance = clib_net_to_host_i32(a->buffer_advance);
    vl_api_flow_t_endian(&a->flow);
}


#endif
#endif /* vl_endianfun */

/****** Version tuple *****/

#ifdef vl_api_version_tuple

vl_api_version_tuple(flow_types.api, 0, 0, 3)

#endif /* vl_api_version_tuple */

/****** API CRC (whole file) *****/

#ifdef vl_api_version
vl_api_version(flow_types.api, 0x23193d51)

#endif

