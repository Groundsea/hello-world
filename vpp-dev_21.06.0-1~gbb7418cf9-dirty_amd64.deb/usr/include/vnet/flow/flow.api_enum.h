#ifndef included_flow_api_enum_h
#define included_flow_api_enum_h
typedef enum {
   VL_API_FLOW_ADD,
   VL_API_FLOW_ADD_REPLY,
   VL_API_FLOW_DEL,
   VL_API_FLOW_DEL_REPLY,
   VL_API_FLOW_ENABLE,
   VL_API_FLOW_ENABLE_REPLY,
   VL_API_FLOW_DISABLE,
   VL_API_FLOW_DISABLE_REPLY,
   VL_MSG_FLOW_LAST
} vl_api_flow_enum_t;
#endif
