/* Imported API files */
#include <vnet/interface_types.api_tojson.h>
#include <vnet/ethernet/ethernet_types.api_tojson.h>
#ifndef included_af_packet_api_tojson_h
#define included_af_packet_api_tojson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline cJSON *vl_api_af_packet_create_t_tojson (vl_api_af_packet_create_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "af_packet_create");
    cJSON_AddItemToObject(o, "hw_addr", vl_api_mac_address_t_tojson(&a->hw_addr));
    cJSON_AddBoolToObject(o, "use_random_hw_addr", a->use_random_hw_addr);
    cJSON_AddStringToObject(o, "host_if_name", (char *)a->host_if_name);
    return o;
}
static inline cJSON *vl_api_af_packet_create_reply_t_tojson (vl_api_af_packet_create_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "af_packet_create_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    cJSON_AddNumberToObject(o, "sw_if_index", a->sw_if_index);
    return o;
}
static inline cJSON *vl_api_af_packet_delete_t_tojson (vl_api_af_packet_delete_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "af_packet_delete");
    cJSON_AddStringToObject(o, "host_if_name", (char *)a->host_if_name);
    return o;
}
static inline cJSON *vl_api_af_packet_delete_reply_t_tojson (vl_api_af_packet_delete_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "af_packet_delete_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    return o;
}
static inline cJSON *vl_api_af_packet_set_l4_cksum_offload_t_tojson (vl_api_af_packet_set_l4_cksum_offload_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "af_packet_set_l4_cksum_offload");
    cJSON_AddNumberToObject(o, "sw_if_index", a->sw_if_index);
    cJSON_AddBoolToObject(o, "set", a->set);
    return o;
}
static inline cJSON *vl_api_af_packet_set_l4_cksum_offload_reply_t_tojson (vl_api_af_packet_set_l4_cksum_offload_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "af_packet_set_l4_cksum_offload_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    return o;
}
static inline cJSON *vl_api_af_packet_dump_t_tojson (vl_api_af_packet_dump_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "af_packet_dump");
    return o;
}
static inline cJSON *vl_api_af_packet_details_t_tojson (vl_api_af_packet_details_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "af_packet_details");
    cJSON_AddNumberToObject(o, "sw_if_index", a->sw_if_index);
    cJSON_AddStringToObject(o, "host_if_name", (char *)a->host_if_name);
    return o;
}
#endif
