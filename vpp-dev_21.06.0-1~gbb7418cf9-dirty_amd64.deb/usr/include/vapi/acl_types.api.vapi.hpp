#ifndef __included_hpp_acl_types_api_json
#define __included_hpp_acl_types_api_json

#include <vapi/vapi.hpp>
#include <vapi/acl_types.api.vapi.h>

namespace vapi {

}
#endif
