#ifndef __included_hpp_ethernet_types_api_json
#define __included_hpp_ethernet_types_api_json

#include <vapi/vapi.hpp>
#include <vapi/ethernet_types.api.vapi.h>

namespace vapi {

}
#endif
