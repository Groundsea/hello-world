#ifndef __included__root_vpp_build_root_build_vpp_native_vpp_CMakeFiles_plugins_tracedump_tracedump_api_json
#define __included__root_vpp_build_root_build_vpp_native_vpp_CMakeFiles_plugins_tracedump_tracedump_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#include <vapi/vpe.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_trace_set_filters;
extern vapi_msg_id_t vapi_msg_id_trace_set_filters_reply;
extern vapi_msg_id_t vapi_msg_id_trace_capture_packets;
extern vapi_msg_id_t vapi_msg_id_trace_capture_packets_reply;
extern vapi_msg_id_t vapi_msg_id_trace_clear_capture;
extern vapi_msg_id_t vapi_msg_id_trace_clear_capture_reply;
extern vapi_msg_id_t vapi_msg_id_trace_dump;
extern vapi_msg_id_t vapi_msg_id_trace_dump_reply;

#define DEFINE_VAPI_MSG_IDS_TRACEDUMP_API_JSON\
  vapi_msg_id_t vapi_msg_id_trace_set_filters;\
  vapi_msg_id_t vapi_msg_id_trace_set_filters_reply;\
  vapi_msg_id_t vapi_msg_id_trace_capture_packets;\
  vapi_msg_id_t vapi_msg_id_trace_capture_packets_reply;\
  vapi_msg_id_t vapi_msg_id_trace_clear_capture;\
  vapi_msg_id_t vapi_msg_id_trace_clear_capture_reply;\
  vapi_msg_id_t vapi_msg_id_trace_dump;\
  vapi_msg_id_t vapi_msg_id_trace_dump_reply;


#ifndef defined_vapi_enum_trace_filter_flag
#define defined_vapi_enum_trace_filter_flag
typedef enum {
  TRACE_FF_NONE = 0,
  TRACE_FF_INCLUDE_NODE = 1,
  TRACE_FF_EXCLUDE_NODE = 2,
  TRACE_FF_INCLUDE_CLASSIFIER = 3,
  TRACE_FF_EXCLUDE_CLASSIFIER = 4,
}  vapi_enum_trace_filter_flag;

#endif

#ifndef defined_vapi_msg_trace_set_filters_reply
#define defined_vapi_msg_trace_set_filters_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_trace_set_filters_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_trace_set_filters_reply payload;
} vapi_msg_trace_set_filters_reply;

static inline void vapi_msg_trace_set_filters_reply_payload_hton(vapi_payload_trace_set_filters_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_trace_set_filters_reply_payload_ntoh(vapi_payload_trace_set_filters_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_trace_set_filters_reply_hton(vapi_msg_trace_set_filters_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_trace_set_filters_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_trace_set_filters_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_trace_set_filters_reply_ntoh(vapi_msg_trace_set_filters_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_trace_set_filters_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_trace_set_filters_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_trace_set_filters_reply_msg_size(vapi_msg_trace_set_filters_reply *msg)
{
  return sizeof(*msg);
}

static void __attribute__((constructor)) __vapi_constructor_trace_set_filters_reply()
{
  static const char name[] = "trace_set_filters_reply";
  static const char name_with_crc[] = "trace_set_filters_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_trace_set_filters_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_trace_set_filters_reply, payload),
    sizeof(vapi_msg_trace_set_filters_reply),
    (generic_swap_fn_t)vapi_msg_trace_set_filters_reply_hton,
    (generic_swap_fn_t)vapi_msg_trace_set_filters_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_trace_set_filters_reply = vapi_register_msg(&__vapi_metadata_trace_set_filters_reply);
  VAPI_DBG("Assigned msg id %d to trace_set_filters_reply", vapi_msg_id_trace_set_filters_reply);
}

static inline void vapi_set_vapi_msg_trace_set_filters_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_trace_set_filters_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_trace_set_filters_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif

#ifndef defined_vapi_msg_trace_set_filters
#define defined_vapi_msg_trace_set_filters
typedef struct __attribute__ ((__packed__)) {
  vapi_enum_trace_filter_flag flag;
  u32 count;
  u32 node_index;
  u32 classifier_table_index; 
} vapi_payload_trace_set_filters;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_trace_set_filters payload;
} vapi_msg_trace_set_filters;

static inline void vapi_msg_trace_set_filters_payload_hton(vapi_payload_trace_set_filters *payload)
{
  payload->flag = (vapi_enum_trace_filter_flag)htobe32(payload->flag);
  payload->count = htobe32(payload->count);
  payload->node_index = htobe32(payload->node_index);
  payload->classifier_table_index = htobe32(payload->classifier_table_index);
}

static inline void vapi_msg_trace_set_filters_payload_ntoh(vapi_payload_trace_set_filters *payload)
{
  payload->flag = (vapi_enum_trace_filter_flag)be32toh(payload->flag);
  payload->count = be32toh(payload->count);
  payload->node_index = be32toh(payload->node_index);
  payload->classifier_table_index = be32toh(payload->classifier_table_index);
}

static inline void vapi_msg_trace_set_filters_hton(vapi_msg_trace_set_filters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_trace_set_filters'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_trace_set_filters_payload_hton(&msg->payload);
}

static inline void vapi_msg_trace_set_filters_ntoh(vapi_msg_trace_set_filters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_trace_set_filters'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_trace_set_filters_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_trace_set_filters_msg_size(vapi_msg_trace_set_filters *msg)
{
  return sizeof(*msg);
}

static inline vapi_msg_trace_set_filters* vapi_alloc_trace_set_filters(struct vapi_ctx_s *ctx)
{
  vapi_msg_trace_set_filters *msg = NULL;
  const size_t size = sizeof(vapi_msg_trace_set_filters);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_trace_set_filters*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_trace_set_filters);

  return msg;
}

static inline vapi_error_e vapi_trace_set_filters(struct vapi_ctx_s *ctx,
  vapi_msg_trace_set_filters *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_trace_set_filters_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_trace_set_filters_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_trace_set_filters_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_trace_set_filters()
{
  static const char name[] = "trace_set_filters";
  static const char name_with_crc[] = "trace_set_filters_f522b44a";
  static vapi_message_desc_t __vapi_metadata_trace_set_filters = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_trace_set_filters, payload),
    sizeof(vapi_msg_trace_set_filters),
    (generic_swap_fn_t)vapi_msg_trace_set_filters_hton,
    (generic_swap_fn_t)vapi_msg_trace_set_filters_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_trace_set_filters = vapi_register_msg(&__vapi_metadata_trace_set_filters);
  VAPI_DBG("Assigned msg id %d to trace_set_filters", vapi_msg_id_trace_set_filters);
}
#endif

#ifndef defined_vapi_msg_trace_capture_packets_reply
#define defined_vapi_msg_trace_capture_packets_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_trace_capture_packets_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_trace_capture_packets_reply payload;
} vapi_msg_trace_capture_packets_reply;

static inline void vapi_msg_trace_capture_packets_reply_payload_hton(vapi_payload_trace_capture_packets_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_trace_capture_packets_reply_payload_ntoh(vapi_payload_trace_capture_packets_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_trace_capture_packets_reply_hton(vapi_msg_trace_capture_packets_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_trace_capture_packets_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_trace_capture_packets_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_trace_capture_packets_reply_ntoh(vapi_msg_trace_capture_packets_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_trace_capture_packets_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_trace_capture_packets_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_trace_capture_packets_reply_msg_size(vapi_msg_trace_capture_packets_reply *msg)
{
  return sizeof(*msg);
}

static void __attribute__((constructor)) __vapi_constructor_trace_capture_packets_reply()
{
  static const char name[] = "trace_capture_packets_reply";
  static const char name_with_crc[] = "trace_capture_packets_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_trace_capture_packets_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_trace_capture_packets_reply, payload),
    sizeof(vapi_msg_trace_capture_packets_reply),
    (generic_swap_fn_t)vapi_msg_trace_capture_packets_reply_hton,
    (generic_swap_fn_t)vapi_msg_trace_capture_packets_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_trace_capture_packets_reply = vapi_register_msg(&__vapi_metadata_trace_capture_packets_reply);
  VAPI_DBG("Assigned msg id %d to trace_capture_packets_reply", vapi_msg_id_trace_capture_packets_reply);
}

static inline void vapi_set_vapi_msg_trace_capture_packets_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_trace_capture_packets_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_trace_capture_packets_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif

#ifndef defined_vapi_msg_trace_capture_packets
#define defined_vapi_msg_trace_capture_packets
typedef struct __attribute__ ((__packed__)) {
  u32 node_index;
  u32 max_packets;
  bool use_filter;
  bool verbose;
  bool pre_capture_clear; 
} vapi_payload_trace_capture_packets;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_trace_capture_packets payload;
} vapi_msg_trace_capture_packets;

static inline void vapi_msg_trace_capture_packets_payload_hton(vapi_payload_trace_capture_packets *payload)
{
  payload->node_index = htobe32(payload->node_index);
  payload->max_packets = htobe32(payload->max_packets);
}

static inline void vapi_msg_trace_capture_packets_payload_ntoh(vapi_payload_trace_capture_packets *payload)
{
  payload->node_index = be32toh(payload->node_index);
  payload->max_packets = be32toh(payload->max_packets);
}

static inline void vapi_msg_trace_capture_packets_hton(vapi_msg_trace_capture_packets *msg)
{
  VAPI_DBG("Swapping `vapi_msg_trace_capture_packets'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_trace_capture_packets_payload_hton(&msg->payload);
}

static inline void vapi_msg_trace_capture_packets_ntoh(vapi_msg_trace_capture_packets *msg)
{
  VAPI_DBG("Swapping `vapi_msg_trace_capture_packets'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_trace_capture_packets_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_trace_capture_packets_msg_size(vapi_msg_trace_capture_packets *msg)
{
  return sizeof(*msg);
}

static inline vapi_msg_trace_capture_packets* vapi_alloc_trace_capture_packets(struct vapi_ctx_s *ctx)
{
  vapi_msg_trace_capture_packets *msg = NULL;
  const size_t size = sizeof(vapi_msg_trace_capture_packets);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_trace_capture_packets*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_trace_capture_packets);

  return msg;
}

static inline vapi_error_e vapi_trace_capture_packets(struct vapi_ctx_s *ctx,
  vapi_msg_trace_capture_packets *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_trace_capture_packets_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_trace_capture_packets_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_trace_capture_packets_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_trace_capture_packets()
{
  static const char name[] = "trace_capture_packets";
  static const char name_with_crc[] = "trace_capture_packets_9e791a9b";
  static vapi_message_desc_t __vapi_metadata_trace_capture_packets = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_trace_capture_packets, payload),
    sizeof(vapi_msg_trace_capture_packets),
    (generic_swap_fn_t)vapi_msg_trace_capture_packets_hton,
    (generic_swap_fn_t)vapi_msg_trace_capture_packets_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_trace_capture_packets = vapi_register_msg(&__vapi_metadata_trace_capture_packets);
  VAPI_DBG("Assigned msg id %d to trace_capture_packets", vapi_msg_id_trace_capture_packets);
}
#endif

#ifndef defined_vapi_msg_trace_clear_capture_reply
#define defined_vapi_msg_trace_clear_capture_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_trace_clear_capture_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_trace_clear_capture_reply payload;
} vapi_msg_trace_clear_capture_reply;

static inline void vapi_msg_trace_clear_capture_reply_payload_hton(vapi_payload_trace_clear_capture_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_trace_clear_capture_reply_payload_ntoh(vapi_payload_trace_clear_capture_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_trace_clear_capture_reply_hton(vapi_msg_trace_clear_capture_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_trace_clear_capture_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_trace_clear_capture_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_trace_clear_capture_reply_ntoh(vapi_msg_trace_clear_capture_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_trace_clear_capture_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_trace_clear_capture_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_trace_clear_capture_reply_msg_size(vapi_msg_trace_clear_capture_reply *msg)
{
  return sizeof(*msg);
}

static void __attribute__((constructor)) __vapi_constructor_trace_clear_capture_reply()
{
  static const char name[] = "trace_clear_capture_reply";
  static const char name_with_crc[] = "trace_clear_capture_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_trace_clear_capture_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_trace_clear_capture_reply, payload),
    sizeof(vapi_msg_trace_clear_capture_reply),
    (generic_swap_fn_t)vapi_msg_trace_clear_capture_reply_hton,
    (generic_swap_fn_t)vapi_msg_trace_clear_capture_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_trace_clear_capture_reply = vapi_register_msg(&__vapi_metadata_trace_clear_capture_reply);
  VAPI_DBG("Assigned msg id %d to trace_clear_capture_reply", vapi_msg_id_trace_clear_capture_reply);
}

static inline void vapi_set_vapi_msg_trace_clear_capture_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_trace_clear_capture_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_trace_clear_capture_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif

#ifndef defined_vapi_msg_trace_clear_capture
#define defined_vapi_msg_trace_clear_capture
typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_trace_clear_capture;

static inline void vapi_msg_trace_clear_capture_hton(vapi_msg_trace_clear_capture *msg)
{
  VAPI_DBG("Swapping `vapi_msg_trace_clear_capture'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_trace_clear_capture_ntoh(vapi_msg_trace_clear_capture *msg)
{
  VAPI_DBG("Swapping `vapi_msg_trace_clear_capture'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline uword vapi_calc_trace_clear_capture_msg_size(vapi_msg_trace_clear_capture *msg)
{
  return sizeof(*msg);
}

static inline vapi_msg_trace_clear_capture* vapi_alloc_trace_clear_capture(struct vapi_ctx_s *ctx)
{
  vapi_msg_trace_clear_capture *msg = NULL;
  const size_t size = sizeof(vapi_msg_trace_clear_capture);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_trace_clear_capture*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_trace_clear_capture);

  return msg;
}

static inline vapi_error_e vapi_trace_clear_capture(struct vapi_ctx_s *ctx,
  vapi_msg_trace_clear_capture *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_trace_clear_capture_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_trace_clear_capture_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_trace_clear_capture_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_trace_clear_capture()
{
  static const char name[] = "trace_clear_capture";
  static const char name_with_crc[] = "trace_clear_capture_51077d14";
  static vapi_message_desc_t __vapi_metadata_trace_clear_capture = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    VAPI_INVALID_MSG_ID,
    sizeof(vapi_msg_trace_clear_capture),
    (generic_swap_fn_t)vapi_msg_trace_clear_capture_hton,
    (generic_swap_fn_t)vapi_msg_trace_clear_capture_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_trace_clear_capture = vapi_register_msg(&__vapi_metadata_trace_clear_capture);
  VAPI_DBG("Assigned msg id %d to trace_clear_capture", vapi_msg_id_trace_clear_capture);
}
#endif

#ifndef defined_vapi_msg_trace_dump_reply
#define defined_vapi_msg_trace_dump_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 last_thread_id;
  u32 last_position;
  u8 more_this_thread;
  u8 more_threads;
  u8 flush_only;
  u8 done; 
} vapi_payload_trace_dump_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_trace_dump_reply payload;
} vapi_msg_trace_dump_reply;

static inline void vapi_msg_trace_dump_reply_payload_hton(vapi_payload_trace_dump_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->last_thread_id = htobe32(payload->last_thread_id);
  payload->last_position = htobe32(payload->last_position);
}

static inline void vapi_msg_trace_dump_reply_payload_ntoh(vapi_payload_trace_dump_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->last_thread_id = be32toh(payload->last_thread_id);
  payload->last_position = be32toh(payload->last_position);
}

static inline void vapi_msg_trace_dump_reply_hton(vapi_msg_trace_dump_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_trace_dump_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_trace_dump_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_trace_dump_reply_ntoh(vapi_msg_trace_dump_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_trace_dump_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_trace_dump_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_trace_dump_reply_msg_size(vapi_msg_trace_dump_reply *msg)
{
  return sizeof(*msg);
}

static void __attribute__((constructor)) __vapi_constructor_trace_dump_reply()
{
  static const char name[] = "trace_dump_reply";
  static const char name_with_crc[] = "trace_dump_reply_e0e87f9d";
  static vapi_message_desc_t __vapi_metadata_trace_dump_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_trace_dump_reply, payload),
    sizeof(vapi_msg_trace_dump_reply),
    (generic_swap_fn_t)vapi_msg_trace_dump_reply_hton,
    (generic_swap_fn_t)vapi_msg_trace_dump_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_trace_dump_reply = vapi_register_msg(&__vapi_metadata_trace_dump_reply);
  VAPI_DBG("Assigned msg id %d to trace_dump_reply", vapi_msg_id_trace_dump_reply);
}

static inline void vapi_set_vapi_msg_trace_dump_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_trace_dump_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_trace_dump_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif

#ifndef defined_vapi_msg_trace_dump
#define defined_vapi_msg_trace_dump
typedef struct __attribute__ ((__packed__)) {
  u8 clear_cache;
  u32 thread_id;
  u32 position;
  u32 max_records; 
} vapi_payload_trace_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_trace_dump payload;
} vapi_msg_trace_dump;

static inline void vapi_msg_trace_dump_payload_hton(vapi_payload_trace_dump *payload)
{
  payload->thread_id = htobe32(payload->thread_id);
  payload->position = htobe32(payload->position);
  payload->max_records = htobe32(payload->max_records);
}

static inline void vapi_msg_trace_dump_payload_ntoh(vapi_payload_trace_dump *payload)
{
  payload->thread_id = be32toh(payload->thread_id);
  payload->position = be32toh(payload->position);
  payload->max_records = be32toh(payload->max_records);
}

static inline void vapi_msg_trace_dump_hton(vapi_msg_trace_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_trace_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_trace_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_trace_dump_ntoh(vapi_msg_trace_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_trace_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_trace_dump_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_trace_dump_msg_size(vapi_msg_trace_dump *msg)
{
  return sizeof(*msg);
}

static inline vapi_msg_trace_dump* vapi_alloc_trace_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_trace_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_trace_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_trace_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_trace_dump);

  return msg;
}

static inline vapi_error_e vapi_trace_dump(struct vapi_ctx_s *ctx,
  vapi_msg_trace_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_trace_dump_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_trace_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_trace_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_trace_dump()
{
  static const char name[] = "trace_dump";
  static const char name_with_crc[] = "trace_dump_c7d6681f";
  static vapi_message_desc_t __vapi_metadata_trace_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_trace_dump, payload),
    sizeof(vapi_msg_trace_dump),
    (generic_swap_fn_t)vapi_msg_trace_dump_hton,
    (generic_swap_fn_t)vapi_msg_trace_dump_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_trace_dump = vapi_register_msg(&__vapi_metadata_trace_dump);
  VAPI_DBG("Assigned msg id %d to trace_dump", vapi_msg_id_trace_dump);
}
#endif


#ifdef __cplusplus
}
#endif

#endif
