#ifndef included_fib_api_enum_h
#define included_fib_api_enum_h
typedef enum {
   VL_API_FIB_SOURCE_ADD,
   VL_API_FIB_SOURCE_ADD_REPLY,
   VL_API_FIB_SOURCE_DUMP,
   VL_API_FIB_SOURCE_DETAILS,
   VL_MSG_FIB_LAST
} vl_api_fib_enum_t;
#endif
