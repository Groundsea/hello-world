#ifndef included_p2p_ethernet_api_enum_h
#define included_p2p_ethernet_api_enum_h
typedef enum {
   VL_API_P2P_ETHERNET_ADD,
   VL_API_P2P_ETHERNET_ADD_REPLY,
   VL_API_P2P_ETHERNET_DEL,
   VL_API_P2P_ETHERNET_DEL_REPLY,
   VL_MSG_P2P_ETHERNET_LAST
} vl_api_p2p_ethernet_enum_t;
#endif
