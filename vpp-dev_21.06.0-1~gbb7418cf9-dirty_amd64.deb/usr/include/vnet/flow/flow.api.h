/*
 * VLIB API definitions 2021-10-16 12:42:48
 * Input file: flow.api
 * Automatically generated: please edit the input file NOT this file!
 */

#include <stdbool.h>
#if defined(vl_msg_id)||defined(vl_union_id) \
    || defined(vl_printfun) ||defined(vl_endianfun) \
    || defined(vl_api_version)||defined(vl_typedefs) \
    || defined(vl_msg_name)||defined(vl_msg_name_crc_list) \
    || defined(vl_api_version_tuple)
/* ok, something was selected */
#else
#warning no content included from flow.api
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))
/* Imported API files */
#ifndef vl_api_version
#include <vnet/interface_types.api.h>
#include <vnet/ip/ip_types.api.h>
#include <vnet/flow/flow_types.api.h>
#endif

/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_FLOW_ADD, vl_api_flow_add_t_handler)
vl_msg_id(VL_API_FLOW_ADD_REPLY, vl_api_flow_add_reply_t_handler)
vl_msg_id(VL_API_FLOW_DEL, vl_api_flow_del_t_handler)
vl_msg_id(VL_API_FLOW_DEL_REPLY, vl_api_flow_del_reply_t_handler)
vl_msg_id(VL_API_FLOW_ENABLE, vl_api_flow_enable_t_handler)
vl_msg_id(VL_API_FLOW_ENABLE_REPLY, vl_api_flow_enable_reply_t_handler)
vl_msg_id(VL_API_FLOW_DISABLE, vl_api_flow_disable_t_handler)
vl_msg_id(VL_API_FLOW_DISABLE_REPLY, vl_api_flow_disable_reply_t_handler)
#endif
/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_flow_add_t, 1)
vl_msg_name(vl_api_flow_add_reply_t, 1)
vl_msg_name(vl_api_flow_del_t, 1)
vl_msg_name(vl_api_flow_del_reply_t, 1)
vl_msg_name(vl_api_flow_enable_t, 1)
vl_msg_name(vl_api_flow_enable_reply_t, 1)
vl_msg_name(vl_api_flow_disable_t, 1)
vl_msg_name(vl_api_flow_disable_reply_t, 1)
#endif
/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_flow \
_(VL_API_FLOW_ADD, flow_add, f946ed84) \
_(VL_API_FLOW_ADD_REPLY, flow_add_reply, 8587dc85) \
_(VL_API_FLOW_DEL, flow_del, b6b9b02c) \
_(VL_API_FLOW_DEL_REPLY, flow_del_reply, e8d4e804) \
_(VL_API_FLOW_ENABLE, flow_enable, 2024be69) \
_(VL_API_FLOW_ENABLE_REPLY, flow_enable_reply, e8d4e804) \
_(VL_API_FLOW_DISABLE, flow_disable, 2024be69) \
_(VL_API_FLOW_DISABLE_REPLY, flow_disable_reply, e8d4e804) 
#endif
/****** Typedefs ******/

#ifdef vl_typedefs
#include "flow.api_types.h"
#endif
/****** Print functions *****/
#ifdef vl_printfun
#ifndef included_flow_printfun_types
#define included_flow_printfun_types


#endif
#endif /* vl_printfun_types */
/****** Print functions *****/
#ifdef vl_printfun
#ifndef included_flow_printfun
#define included_flow_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_flow_add_t_print (vl_api_flow_add_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_flow_add_t: */
    s = format(s, "vl_api_flow_add_t:");
    s = format(s, "\n%Uflow: %U", format_white_space, indent, format_vl_api_flow_rule_t, &a->flow, indent);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_flow_add_reply_t_print (vl_api_flow_add_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_flow_add_reply_t: */
    s = format(s, "vl_api_flow_add_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    s = format(s, "\n%Uflow_index: %u", format_white_space, indent, a->flow_index);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_flow_del_t_print (vl_api_flow_del_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_flow_del_t: */
    s = format(s, "vl_api_flow_del_t:");
    s = format(s, "\n%Uflow_index: %u", format_white_space, indent, a->flow_index);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_flow_del_reply_t_print (vl_api_flow_del_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_flow_del_reply_t: */
    s = format(s, "vl_api_flow_del_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_flow_enable_t_print (vl_api_flow_enable_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_flow_enable_t: */
    s = format(s, "vl_api_flow_enable_t:");
    s = format(s, "\n%Uflow_index: %u", format_white_space, indent, a->flow_index);
    s = format(s, "\n%Uhw_if_index: %u", format_white_space, indent, a->hw_if_index);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_flow_enable_reply_t_print (vl_api_flow_enable_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_flow_enable_reply_t: */
    s = format(s, "vl_api_flow_enable_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_flow_disable_t_print (vl_api_flow_disable_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_flow_disable_t: */
    s = format(s, "vl_api_flow_disable_t:");
    s = format(s, "\n%Uflow_index: %u", format_white_space, indent, a->flow_index);
    s = format(s, "\n%Uhw_if_index: %u", format_white_space, indent, a->hw_if_index);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_flow_disable_reply_t_print (vl_api_flow_disable_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_flow_disable_reply_t: */
    s = format(s, "vl_api_flow_disable_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}


#endif
#endif /* vl_printfun */

/****** Endian swap functions *****/
#ifdef vl_endianfun
#ifndef included_flow_endianfun
#define included_flow_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_flow_add_t_endian (vl_api_flow_add_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    /* a->client_index = a->client_index (no-op) */
    a->context = clib_net_to_host_u32(a->context);
    vl_api_flow_rule_t_endian(&a->flow);
}

static inline void vl_api_flow_add_reply_t_endian (vl_api_flow_add_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_i32(a->retval);
    a->flow_index = clib_net_to_host_u32(a->flow_index);
}

static inline void vl_api_flow_del_t_endian (vl_api_flow_del_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    /* a->client_index = a->client_index (no-op) */
    a->context = clib_net_to_host_u32(a->context);
    a->flow_index = clib_net_to_host_u32(a->flow_index);
}

static inline void vl_api_flow_del_reply_t_endian (vl_api_flow_del_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_i32(a->retval);
}

static inline void vl_api_flow_enable_t_endian (vl_api_flow_enable_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    /* a->client_index = a->client_index (no-op) */
    a->context = clib_net_to_host_u32(a->context);
    a->flow_index = clib_net_to_host_u32(a->flow_index);
    a->hw_if_index = clib_net_to_host_u32(a->hw_if_index);
}

static inline void vl_api_flow_enable_reply_t_endian (vl_api_flow_enable_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_i32(a->retval);
}

static inline void vl_api_flow_disable_t_endian (vl_api_flow_disable_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    /* a->client_index = a->client_index (no-op) */
    a->context = clib_net_to_host_u32(a->context);
    a->flow_index = clib_net_to_host_u32(a->flow_index);
    a->hw_if_index = clib_net_to_host_u32(a->hw_if_index);
}

static inline void vl_api_flow_disable_reply_t_endian (vl_api_flow_disable_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_i32(a->retval);
}


#endif
#endif /* vl_endianfun */

/****** Version tuple *****/

#ifdef vl_api_version_tuple

vl_api_version_tuple(flow.api, 0, 0, 2)

#endif /* vl_api_version_tuple */

/****** API CRC (whole file) *****/

#ifdef vl_api_version
vl_api_version(flow.api, 0xda63a2f4)

#endif

